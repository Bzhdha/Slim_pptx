# Slim PPTX - Version Portable

## Utilisation

1. Double-cliquez sur `Slim_PPTX.exe` pour lancer l'application
2. Glissez-déposez votre fichier PowerPoint dans la fenêtre
3. Suivez les instructions à l'écran pour optimiser votre fichier

## Fonctionnalités

- Analyse des images dans les présentations PowerPoint
- Détection des images non utilisées
- Création de versions allégées
- Gestion des images rognées
- Interface graphique intuitive

## Support

Pour toute question ou problème, consultez la documentation complète.

## Version

Cette version portable ne nécessite aucune installation.
